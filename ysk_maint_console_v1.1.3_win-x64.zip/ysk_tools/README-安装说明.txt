解包到 D:\ProgramFiles\ysk_tools\ 即可（保持目录层级）。
入口：双击 ysk_维护操作台.bat = 窗口版；加参数 tty = 原终端交互版。
v1.1.3 需配套脚本 run\ysk_maint_console.ps1（本包已含）。
