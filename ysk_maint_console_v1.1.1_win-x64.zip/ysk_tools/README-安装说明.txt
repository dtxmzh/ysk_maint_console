解包到 D:\ProgramFiles\ysk_tools\ 即可（保持目录层级）。
入口：双击 ysk_维护操作台.bat = 窗口版；加参数 tty = 原终端交互版。
首次运行若火绒拦截，把 ysk_maint_console\ 目录加入信任区。
v1.1.1 需配套脚本 run\ysk_maint_console.ps1（本包已含）与 TTS 服务端
E:\DSDeployMaster\yosuko-tts\yosuko_server.py 的 /gpu/load?device= 支持。
