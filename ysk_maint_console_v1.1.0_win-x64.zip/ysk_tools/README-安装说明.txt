解包到 D:\ProgramFiles\ysk_tools\ 即可（保持目录层级）。
入口：双击 ysk_维护操作台.bat = 窗口版；加参数 tty = 原终端交互版。
首次运行若火绒拦截，把 ysk_maint_console\ 目录加入信任区。
v1.1.0 需要配套脚本 run\ysk_maint_console.ps1（本包已含）；选卡功能另依赖
E:\DSDeployMaster\ysk_autostart\ 下各 serve_*.bat 的 YSK_GPU 支持（本机已就位）。
